clf
t=0:0.01:3*pi;
y1=2*sin(t);
y2=2*sin(t-2);
plot(t,y1,'r-');
hold on;
plot(t,y2,'b:');
