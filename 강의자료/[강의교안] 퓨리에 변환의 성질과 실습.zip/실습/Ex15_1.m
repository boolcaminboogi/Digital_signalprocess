% �ǽ� 15-1: Exp15_1.m 
% X = 1/(a+jw);
a = 1;
w = -20:.05:20;
X = 1./(a+j*w);
mag = abs(X);
plot(w,mag);
axis([-20 20 0 1]);
xlabel('frequency(rad/sec)');
ylabel('magnitude');
grid on
phase = angle(X);
phase = phase*180/pi; % ���� degree�� ��ȯ
figure
plot(w,phase);
xlabel('frequency(rad/sec)');
ylabel('phase(degree)');
grid on


